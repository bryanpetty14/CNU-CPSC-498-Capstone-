<?php
 $hostName = "budgethelperdb.cxhmghpewoq4.us-west-2.rds.amazonaws.com";
 $hostUser = "scrublord";
 $hostPass = "Janper12!";
 $dbName = "budgetHelperDB";
 ?>