<?php
include 'databaseConfig.php';
error_reporting(E_ERROR | E_PARSE);
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);
if($db->connect_errno){
	echo "database down";
}else{
	$username = $_POST['username'];
	$category = $_POST['category'];
	if($username && $category){
		$query = "SELECT * FROM budget WHERE user_username = '" . $username . "' and category = '$category'";
		$result = $db->query($query);
		
		//adapted from www.camposha.info/android/php-mysql-listview/
		while($row = mysqli_fetch_array($result)){
			$flag[] = $row;
		}
		if($flag){
			echo(json_encode($flag));
		}else{
			echo "[]";
		}
	}else{
		echo "Not all required values given";
	}
	$db->close();
}
?>