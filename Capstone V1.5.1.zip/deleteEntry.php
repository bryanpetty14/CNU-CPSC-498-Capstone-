<?php
include 'databaseConfig.php';
error_reporting(E_ERROR | E_PARSE);
$db = new mysqli($hostName, $hostUser, $hostPass, $dbName);
if($db->connect_errno){
	echo "database down";
}else{
	$username = $_POST['username'];
	$category = $_POST['category'];
	$year = $_POST['year'];
	$month = $_POST['month'];
	$day = $_POST['day'];
	$description =$_POST['description'];
	$amount = $_POST['amount'];
	$place = $_POST['place'];
	if($username&&$category&&$year&&$month&&$day&&$description&&$amount&&$place){
		$query = "delete from entry where user_username = '$username' and dateEntered = '$year-$month-$day' 
		and category_Name = '$category' and description ='$description' and cost = $amount and placeSpent = '$place'";
		$result = $db->query($query);
		if($result){
			echo "Data Deleted Successfully";
		}
		else{
			echo "Error Deleteing Data";
		}
	}
	else{
		echo "Not all required values given";
	}
	$db->close();
}
?>

